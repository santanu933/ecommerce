
from flask import Flask,request,jsonify,send_file
from flask_cors import CORS
import csv,os
from datetime import datetime

app=Flask(__name__)
CORS(app)
CSV='orders.csv'

FIELDS=['OrderID','Created','Customer','Phone','Address','Payment','Items','Total','Status']

def read_orders():
    if not os.path.exists(CSV): return []
    with open(CSV,'r',encoding='utf-8') as f:
        return list(csv.DictReader(f))

def save_orders(rows):
    with open(CSV,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)

@app.route('/place-order',methods=['POST'])
def place_order():
    d=request.json
    rows=read_orders()
    oid=len(rows)+1
    total=sum(i['price']*i['qty'] for i in d['items'])
    rows.append({
      'OrderID':oid,
      'Created':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
      'Customer':d.get('name'),
      'Phone':d.get('phone'),
      'Address':d.get('address'),
      'Payment':d.get('payment'),
      'Items':'; '.join([f"{i['name']} x{i['qty']}" for i in d['items']]),
      'Total':total,
      'Status':'Placed'
    })
    save_orders(rows)
    return jsonify({'success':True,'orderId':oid})

@app.route('/orders')
def orders():
    return jsonify(read_orders())

@app.route('/update-status/<int:oid>/<status>')
def update_status(oid,status):
    rows=read_orders()
    for r in rows:
        if int(r['OrderID'])==oid:
            r['Status']=status
    save_orders(rows)
    return jsonify({'success':True})

@app.route('/download-csv')
def download_csv():
    return send_file(CSV,as_attachment=True)

if __name__=='__main__':
    app.run(debug=True,port=5000)
