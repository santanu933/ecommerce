
Backend:
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py

Customer:
open frontend/index.html

Admin:
open frontend/admin.html

Download CSV:
http://127.0.0.1:5000/download-csv
